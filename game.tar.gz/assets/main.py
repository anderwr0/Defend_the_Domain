import asyncio
from pathlib import Path
import pygame

WIDTH, HEIGHT = 900, 600
BASE_DIR = Path(__file__).parent
TEXT_DIR = BASE_DIR / 'text'
ASSET_DIR = BASE_DIR / 'assets'


def story(filename):
    path = TEXT_DIR / filename
    if path.exists():
        return path.read_text(encoding='utf-8').strip()
    return 'Missing story file: ' + filename


class NPCs:
    def __init__(self, name, armor, description):
        self.name = name
        self.armor = armor
        self.description = description


class Treasure:
    def __init__(self, name, value, description):
        self.name = name
        self.value = value
        self.description = description


class Tool:
    def __init__(self, name, damage, description):
        self.name = name
        self.damage = damage
        self.description = description


class Room:
    def __init__(self, name, description, enter_sound=None):
        self.name = name
        self.description = description
        self.enter_sound = enter_sound
        self.neighbors = {}
        self.NPCs = None
        self.treasure = None
        self.tool = None

    def add_neighbor(self, direction, room):
        self.neighbors[direction] = room

    def get_neighbor(self, direction):
        return self.neighbors.get(direction)

    def list_exits(self):
        return ', '.join(self.neighbors.keys())


class TextAdventure:
    def __init__(self):
        self.messages = []
        self.current_input = ''
        self.scroll = 0
        self.inventory = []
        self.score = 0
        self.game_over = False
        self.ending = None
        self.visited = []
        self.fire_discovered = False
        self.chief_met = False
        self.truck_unlocked = False
        self.hose_used = False
        self.found_roommate = False
        self.med_kit_found = False
        self.desk_searched = False
        self.drawer_searched = False
        self.locker_searched = False
        self.roommate_stable = False
        self.backup_called = False
        self.choice_made = False
        self.route_choice = False
        # Audio files created by the music teammate.
        self.audio_on = True
        self.current_music = ''
        self.sounds = {}
        sound_files = {
            'move': 'Walking Sound.ogg',
            'alarm': 'Smoke Detector Sound..ogg',
            'radio': 'Static Machine Sound.ogg',
            'thinking': 'Thinking Sound..ogg',
            'creepy': 'Creepy Thinking Sound.ogg',
        }
        if pygame.mixer.get_init():
            for name, filename in sound_files.items():
                path = ASSET_DIR / filename
                if path.exists():
                    try:
                        self.sounds[name] = pygame.mixer.Sound(str(path))
                        self.sounds[name].set_volume(0.35)
                    except (pygame.error, OSError):
                        pass
            # Keep the old pickup / win sounds if the original files are present.
            for name in ['pickup', 'win', 'danger']:
                path = ASSET_DIR / (name + '.wav')
                if path.exists():
                    try:
                        self.sounds[name] = pygame.mixer.Sound(str(path))
                        self.sounds[name].set_volume(0.35)
                    except (pygame.error, OSError):
                        pass

        aers = Room('Dorm Room', story('aers_dorm.txt'))
        clurg = Room('McClurg', story('clurg.txt'))
        station = Room('Fire Station', story('fire_station.txt'))
        gailor = Room('Gailor Hall', story('gailor_intro.txt'), 'danger')
        hospital = Room('Hospital', story('hospital.txt'))

        aers.add_neighbor('north', clurg)
        clurg.add_neighbor('south', aers)
        clurg.add_neighbor('east', station)
        station.add_neighbor('west', clurg)
        clurg.add_neighbor('north', gailor)
        gailor.add_neighbor('south', clurg)
        gailor.add_neighbor('north', hospital)
        hospital.add_neighbor('south', gailor)

        gailor.NPCs = NPCs('roommate', 2, story('hurt_roommate.txt'))
        station.tool = Tool('water hose', 5, story('water_hose.txt'))
        self.dorm_room = aers
        self.fire_station = station
        self.gailor = gailor
        self.hospital = hospital
        self.current_room = aers
        self.say('WELCOME TO DEFEND THE DOMAIN!')
        self.say('Type help for commands. Scroll with mouse wheel or Page Up / Page Down.')
        self.announce_room()
        self.update_music()

    def say(self, message):
        self.messages.append(str(message))
        self.scroll = 0

    def scene(self, filename):
        self.say(story(filename))

    def play_sound(self, name):
        if self.audio_on and name in self.sounds:
            self.sounds[name].play()

    def update_music(self):
        if not pygame.mixer.get_init():
            return
        if self.game_over:
            filename = 'Thinking Sound..ogg' if self.ending != 'secret' else 'Game Intro_Background Music .ogg'
        elif self.current_room.name == 'Hospital':
            filename = 'Hospital Heart Monitor.ogg'
        elif self.current_room.name == 'Gailor Hall':
            filename = 'Fire Burning Sound.ogg'
        elif self.current_room.name == 'Fire Station' and self.fire_discovered:
            filename = 'Fire Burning Sound.ogg'
        else:
            filename = 'Game Intro_Background Music .ogg'
        if filename == self.current_music:
            return
        self.current_music = filename
        pygame.mixer.music.stop()
        path = ASSET_DIR / filename
        if path.exists():
            try:
                pygame.mixer.music.load(str(path))
                pygame.mixer.music.set_volume(0.25)
                if self.audio_on:
                    pygame.mixer.music.play(-1)
            except (pygame.error, OSError):
                pass

    def set_audio(self, enabled):
        self.audio_on = enabled
        if pygame.mixer.get_init():
            if enabled:
                if self.current_music:
                    self.current_music = ''
                self.update_music()
            else:
                pygame.mixer.music.stop()
                pygame.mixer.stop()
        self.say('Audio turned ' + ('on.' if enabled else 'off.'))

    def announce_room(self):
        room = self.current_room
        self.say('You are in the ' + room.name + '.')
        if room.name not in self.visited:
            self.visited.append(room.name)
            self.scene_for_first_visit()
        else:
            self.say('Type look to examine the area. Exits: ' + room.list_exits())
        self.room_hint()

    def scene_for_first_visit(self):
        name = self.current_room.name
        if name == 'Dorm Room':
            self.scene('aers_dorm.txt')
        elif name == 'McClurg':
            self.scene('clurg.txt')
            self.fire_discovered = True
        elif name == 'Gailor Hall':
            self.scene('gailor_intro.txt')
            self.chief_met = True
            self.play_sound('alarm')
            self.inventory.append('truck key')
            self.say('The chief hands you the FIRE TRUCK KEY. It is now in your inventory.')
            self.say('Return to the Fire Station and unlock the truck to get the water hose.')
        elif name == 'Fire Station':
            self.say('The fire truck is parked here. Its equipment compartment is locked.')
        elif name == 'Hospital':
            self.scene('hospital.txt')

    def room_hint(self):
        name = self.current_room.name
        if name == 'Dorm Room' and self.found_roommate and not self.med_kit_found:
            self.say('You remember that a med kit is somewhere in the room. Try searching.')
        if name == 'Fire Station' and self.chief_met and not self.truck_unlocked:
            self.say('You have the key. Type use truck key to unlock the fire truck.')
        if name == 'Gailor Hall':
            if not self.hose_used:
                self.say('The flames block the way. You need a water hose before you can reach anyone.')
            elif not self.roommate_stable:
                self.say('Your roommate needs first aid. Find the med kit in your dorm room.')
            elif not self.choice_made:
                self.say('Decision: choose fight or choose rescue.')
        self.say('Exits: ' + self.current_room.list_exits())

    def look(self):
        name = self.current_room.name
        if name == 'Dorm Room':
            self.say('Your desk, bed, closet, and drawer are available to search.')
            if self.found_roommate and not self.med_kit_found:
                self.say('The med kit must be around here somewhere.')
        elif name == 'Fire Station':
            self.say('A fire truck is parked here. There is also a locker.')
            if not self.truck_unlocked:
                self.say('The truck compartment is locked.')
            elif 'water hose' not in self.inventory:
                self.say('The water hose is ready. Type take water hose.')
        elif name == 'Gailor Hall':
            if not self.hose_used:
                self.say('Flames block the entrance. The chief is directing the emergency.')
            else:
                self.say('You have cleared a path through the flames. Your injured roommate is nearby.')
        elif name == 'Hospital':
            self.say('Medical staff are ready to help your roommate.')
        else:
            self.say('The dining hall patio looks toward Gailor Hall.')
        self.say('Exits: ' + self.current_room.list_exits())

    def go(self, direction):
        destination = self.current_room.get_neighbor(direction)
        if destination is None:
            self.say("You can't go that way.")
            return
        if destination == self.hospital:
            if not self.roommate_stable:
                self.say('You cannot go to the hospital yet. Your roommate needs to be stabilized first.')
                return
            if not self.choice_made:
                self.say('First decide what to do: choose rescue or choose fight.')
                return
            if self.choice_made != 'rescue' and self.choice_made != 'backup':
                self.say('You have chosen to enter the building. Finish the rescue first.')
                return
        self.current_room = destination
        self.play_sound('move')
        if destination.enter_sound:
            self.play_sound(destination.enter_sound)
        self.announce_room()
        self.update_music()
        if destination == self.hospital and self.choice_made == 'rescue':
            self.end_game('roommate')
        elif destination == self.hospital and self.choice_made == 'backup':
            self.end_game('secret')

    def search(self, place):
        name = self.current_room.name
        if name == 'Dorm Room':
            if place == 'desk':
                self.desk_searched = True
                if 'frequency note' not in self.inventory:
                    self.say('You find a handwritten emergency frequency note on your desk.')
                    self.say('Type take frequency note to keep it.')
                else:
                    self.say('There is nothing else on the desk.')
            elif place == 'drawer':
                self.drawer_searched = True
                if 'radio' not in self.inventory:
                    self.say('An old emergency radio is tucked inside the drawer. Its battery is dead.')
                    self.say('Type take radio to keep it.')
                else:
                    self.say('The drawer is empty.')
            elif place == 'closet':
                self.say('You search your closet. Just clothes and old shoes. Maybe check the bed.')
            elif place in ['bed', 'under bed', 'roommate bed']:
                if not self.found_roommate:
                    self.say('You look beneath the bed, but nothing seems important right now.')
                elif not self.med_kit_found:
                    self.med_kit_found = True
                    self.dorm_room.treasure = Treasure('med kit', 10, story('med_kit.txt'))
                    self.say(story('med_kit.txt'))
                    self.say('Type take med kit.')
                else:
                    self.say('You already searched beneath the bed.')
            else:
                self.say('Try searching the desk, drawer, closet, or bed.')
        elif name == 'Fire Station':
            if place == 'locker':
                self.locker_searched = True
                self.say('Inside the locker is a spare radio battery.')
                if 'battery' not in self.inventory:
                    self.say('Type take battery.')
            elif place in ['truck', 'fire truck']:
                if self.truck_unlocked:
                    self.say('The truck is unlocked. The water hose is inside.')
                else:
                    self.say('The fire truck is locked. You need the truck key.')
            else:
                self.say('Try searching the locker or truck.')
        else:
            self.say('There is nothing useful to search here.')

    def take(self, name):
        if name in self.inventory:
            self.say('You already have that item.')
            return
        room = self.current_room.name
        if room == 'Dorm Room' and name in ['radio', 'frequency note']:
            if name == 'radio' and not self.drawer_searched:
                self.say('Search the room to find the radio first.')
                return
            if name == 'frequency note' and not self.desk_searched:
                self.say('Search the room to find the note first.')
                return
            self.inventory.append(name)
        elif room == 'Dorm Room' and name == 'med kit' and self.med_kit_found and self.dorm_room.treasure:
            self.inventory.append(name)
            self.dorm_room.treasure = None
        elif room == 'Fire Station' and name == 'battery':
            # The player must discover the battery by searching first.
            if not self.locker_searched:
                self.say('Search the locker first.')
                return
            self.inventory.append(name)
        elif room == 'Fire Station' and name in ['water hose', 'hose']:
            if not self.truck_unlocked:
                self.say('The water hose is locked in the fire truck.')
                return
            self.inventory.append('water hose')
            self.fire_station.tool = None
            name = 'water hose'
        else:
            self.say('You cannot take that here. Try look or search.')
            return
        self.say('You picked up the ' + name + '!')
        self.play_sound('pickup')

    def show_inventory(self):
        if self.inventory:
            self.say('Inventory: ' + ', '.join(self.inventory))
        else:
            self.say('Your inventory is empty.')

    def use(self, name):
        if name not in self.inventory:
            self.say("You don't have that item.")
            return
        room = self.current_room.name
        if name == 'truck key':
            if room != 'Fire Station':
                self.say('Use the truck key at the Fire Station.')
            elif not self.truck_unlocked:
                self.truck_unlocked = True
                self.say('You unlock the fire truck! The water hose is inside. Type take water hose.')
            else:
                self.say('The fire truck is already unlocked.')
        elif name == 'water hose':
            if room != 'Gailor Hall':
                self.say('You need to be at Gailor Hall to fight the flames.')
            elif not self.hose_used:
                self.hose_used = True
                self.say('You spray the flames with the water hose, clearing a safe path.')
                self.scene('roommate_discovery.txt')
                self.found_roommate = True
                self.say('You remember a med kit somewhere back in your dorm room.')
                self.play_sound('danger')
            else:
                self.say('The path is already clear, but the building is still burning.')
        elif name == 'med kit':
            if room != 'Gailor Hall' or not self.found_roommate:
                self.say('Your roommate needs this at Gailor Hall.')
            elif self.roommate_stable:
                self.say('You already stabilized your roommate.')
            else:
                self.inventory.remove('med kit')
                self.roommate_stable = True
                self.scene('stabilize_roommate.txt')
                self.play_sound('thinking')
                self.say('Now choose fight or choose rescue. Think carefully.')
        elif name == 'radio':
            if room != 'Gailor Hall' or not self.roommate_stable:
                self.say('You should contact backup from Gailor after helping your roommate.')
            elif 'battery' not in self.inventory:
                self.say('The radio has no working battery.')
            elif 'frequency note' not in self.inventory:
                self.say('The radio works, but you do not know the emergency frequency.')
            elif not self.backup_called:
                self.backup_called = True
                self.scene('backup_call.txt')
                self.play_sound('radio')
                self.say('You can now choose coordinate, choose rescue, or choose fight.')
            else:
                self.say('Backup has already been dispatched.')
        elif name == 'battery':
            self.say('The battery fits your radio. Type use radio when you are ready.')
        elif name == 'frequency note':
            self.say('The note lists an emergency frequency. It might help with a radio.')
        else:
            self.say("You can't use that item here.")

    def choose(self, decision):
        if self.current_room.name != 'Gailor Hall':
            self.say('There is no decision to make here.')
            return
        if not self.roommate_stable:
            self.say('First reach and stabilize your roommate.')
            return
        if self.choice_made:
            self.say('You have already made your decision.')
            return
        if decision in ['coordinate', 'backup']:
            if not self.backup_called:
                self.say('You cannot coordinate a rescue without calling backup.')
                return
            self.choice_made = 'backup'
            self.scene('coordinate_rescue.txt')
            self.say('Go north to accompany your roommate to the hospital.')
        elif decision in ['rescue', 'roommate']:
            self.choice_made = 'rescue'
            self.scene('save_roommate.txt')
            self.say('Go north to travel with your roommate to the hospital.')
        elif decision == 'fight':
            self.choice_made = 'fight'
            self.scene('follow_orders.txt')
            self.play_sound('creepy')
            self.say('Type choose beam to cross the beam, or choose long route to go around.')
        else:
            self.say('Choose fight or choose rescue.')

    def choose_route(self, decision):
        if self.choice_made != 'fight' or self.current_room.name != 'Gailor Hall':
            self.say('There is no route decision right now.')
            return
        if decision in ['beam', 'cross', 'cross beam']:
            self.end_game('beam')
        elif decision in ['long', 'long route', 'around', 'safe']:
            self.end_game('students')
        else:
            self.say('Choose beam or choose long route.')

    def end_game(self, ending):
        self.ending = ending
        self.game_over = True
        self.scene('ending_' + ending + '.txt')
        self.say('THE END - Type restart to play again, or press Esc to quit.')
        self.update_music()
        self.play_sound('win' if ending == 'secret' else 'danger')

    def handle_command(self, line):
        if not line.strip():
            return
        self.say('> ' + line)
        words = line.lower().strip().split()
        command = words[0]
        target = ' '.join(words[1:])
        if command == 'music' and target in ['on', 'off']:
            self.set_audio(target == 'on')
        elif command == 'help':
            self.say('Commands: look, go DIRECTION, search PLACE, take ITEM, use ITEM, inventory, choose OPTION, music on, music off, restart')
            self.say('Use the mouse wheel or Page Up / Page Down to read longer story passages.')
        elif command == 'look':
            self.look()
        elif command == 'go':
            self.go(target)
        elif command == 'search':
            self.search(target)
        elif command == 'take':
            self.take(target)
        elif command == 'use':
            self.use(target)
        elif command == 'inventory':
            self.show_inventory()
        elif command == 'choose':
            if self.choice_made == 'fight':
                self.choose_route(target)
            else:
                self.choose(target)
        else:
            self.say("I don't understand that. Type help for commands.")


def wrap_text(text, font, max_width):
    lines = []
    for paragraph in text.split('\n'):
        words = paragraph.split()
        current = ''
        for word in words:
            test = word if not current else current + ' ' + word
            if font.size(test)[0] <= max_width:
                current = test
            else:
                if current:
                    lines.append(current)
                current = word
        lines.append(current)
    return lines


def draw_game(screen, font, small_font, game):
    screen.fill((24, 24, 28))
    title = font.render('Defend the Domain!', True, (240, 240, 245))
    screen.blit(title, (30, 18))
    location = small_font.render('Location: ' + game.current_room.name, True, (170, 190, 220))
    screen.blit(location, (WIDTH - location.get_width() - 30, 27))
    lines = []
    for message in game.messages:
        lines.extend(wrap_text(message, small_font, WIDTH - 70))
        lines.append('')
    max_visible = 18
    max_scroll = max(0, len(lines) - max_visible)
    game.scroll = min(game.scroll, max_scroll)
    start = max(0, len(lines) - max_visible - game.scroll)
    visible = lines[start:start + max_visible]
    y = 68
    for line in visible:
        if line:
            screen.blit(small_font.render(line, True, (220, 220, 225)), (30, y))
        y += 24
    pygame.draw.line(screen, (100, 100, 110), (30, HEIGHT - 70), (WIDTH - 30, HEIGHT - 70), 2)
    prompt = '> ' + game.current_input
    if len(prompt) > 95:
        prompt = prompt[-95:]
    screen.blit(small_font.render(prompt, True, (255, 255, 255)), (30, HEIGHT - 48))
    scroll_info = small_font.render('Scroll: mouse wheel / PgUp / PgDn', True, (145, 145, 155))
    screen.blit(scroll_info, (WIDTH - scroll_info.get_width() - 30, HEIGHT - 19))


async def main():
    pygame.init()
    try:
        pygame.mixer.init()
    except pygame.error:
        pass
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption('Defend the Domain!')
    clock = pygame.time.Clock()
    font = pygame.font.Font(None, 32)
    small_font = pygame.font.Font(None, 22)
    game = TextAdventure()
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEWHEEL:
                game.scroll = max(0, game.scroll + event.y * 3)
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                elif event.key == pygame.K_PAGEUP:
                    game.scroll += 12
                elif event.key == pygame.K_PAGEDOWN:
                    game.scroll = max(0, game.scroll - 12)
                elif event.key == pygame.K_RETURN:
                    command = game.current_input.strip()
                    game.current_input = ''
                    if command.lower() == 'restart':
                        if pygame.mixer.get_init():
                            pygame.mixer.stop()
                            pygame.mixer.music.stop()
                        game = TextAdventure()
                    elif not game.game_over:
                        game.handle_command(command)
                    elif command:
                        game.say('The game has ended. Type restart to play again.')
                elif event.key == pygame.K_BACKSPACE:
                    game.current_input = game.current_input[:-1]
                elif event.unicode and event.unicode.isprintable():
                    game.current_input += event.unicode
        draw_game(screen, font, small_font, game)
        pygame.display.flip()
        clock.tick(60)
        await asyncio.sleep(0)
    pygame.quit()


if __name__ == '__main__':
    asyncio.run(main())
